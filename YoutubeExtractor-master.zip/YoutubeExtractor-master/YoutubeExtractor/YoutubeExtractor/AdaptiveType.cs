﻿namespace YoutubeExtractor
{
    public enum AdaptiveType
    {
        None,
        Audio,
        Video
    }
}