﻿using System.Reflection;

// General Information about an assembly is controlled through the following set of attributes.
// Change these attribute values to modify the information associated with an assembly.
[assembly: AssemblyTitle("YoutubeExtractor")]
[assembly: AssemblyDescription("YoutubeExtractor is a library for .NET, written in C#, to extract the download link from YouTube videos, download them, and/or extract their audio track.")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("YoutubeExtractor")]
[assembly: AssemblyCopyright("Copyright © 2015")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: AssemblyVersion("0.10.11")]
[assembly: AssemblyFileVersion("0.10.11")]